export function Button({ children, onClick }: { children: React.ReactNode, onClick?: () => void }) {
  return <button onClick={onClick} className="p-2 bg-blue-600 text-white rounded w-full">{children}</button>;
}