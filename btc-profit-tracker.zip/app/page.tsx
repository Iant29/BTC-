'use client';
import ProfitToBTCTracker from '../components/ProfitToBTCTracker';

export default function Home() {
  return <ProfitToBTCTracker />;
}