export function Input(props: any) {
  return <input {...props} className="p-2 border rounded w-full" />;
}