'use client';
import { useState } from "react";
import { Card, CardContent } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

export default function ProfitToBTCTracker() {
  const [entries, setEntries] = useState([]);
  const [coin, setCoin] = useState("");
  const [profit, setProfit] = useState("");
  const [btcRate, setBtcRate] = useState(770000000);

  const addEntry = () => {
    const profitNumber = parseFloat(profit);
    if (coin && !isNaN(profitNumber)) {
      const btcAmount = (profitNumber * 0.7) / btcRate;
      const newEntry = {
        date: new Date().toLocaleDateString(),
        coin,
        profit: profitNumber,
        btc: btcAmount,
      };
      setEntries([...entries, newEntry]);
      setCoin("");
      setProfit("");
    }
  };

  const totalBTC = entries.reduce((sum, e) => sum + e.btc, 0);

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Crypto Spot → BTC Profit Tracker</h1>
      <div className="grid grid-cols-1 gap-2 mb-4">
        <Input placeholder="Nama Coin (misal: TIA, RNDR)" value={coin} onChange={(e) => setCoin(e.target.value)} />
        <Input type="number" placeholder="Profit Hari Ini (Rp)" value={profit} onChange={(e) => setProfit(e.target.value)} />
        <Button onClick={addEntry}>Tambah</Button>
      </div>
      <Card>
        <CardContent className="p-4">
          <h2 className="font-semibold mb-2">Log Harian</h2>
          {entries.length === 0 ? (
            <p className="text-sm">Belum ada data.</p>
          ) : (
            <ul className="text-sm">
              {entries.map((e, i) => (
                <li key={i} className="mb-1">
                  {e.date} - {e.coin}: Rp {e.profit.toLocaleString()} → {e.btc.toFixed(6)} BTC
                </li>
              ))}
            </ul>
          )}
          <div className="mt-4 font-semibold">
            Total BTC Terkumpul: {totalBTC.toFixed(6)} BTC
          </div>
        </CardContent>
      </Card>
    </div>
  );
}